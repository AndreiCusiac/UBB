//
// Created by Virginia Niculescu on 11/20/20.
//

#ifndef EXEMPLE_FUTURE_PROMISE_TEST_SHARED_FUTURE_H
#define EXEMPLE_FUTURE_PROMISE_TEST_SHARED_FUTURE_H


#include <iostream>
#include <future>
#include <chrono>
int test_shared_future();

#endif //EXEMPLE_FUTURE_PROMISE_TEST_SHARED_FUTURE_H
