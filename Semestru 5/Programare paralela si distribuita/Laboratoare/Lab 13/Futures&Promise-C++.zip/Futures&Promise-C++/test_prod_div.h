//
// Created by Virginia Niculescu on 11/23/20.
//

#ifndef EXEMPLE_FUTURE_PROMISE_TEST_PROD_DIV_H
#define EXEMPLE_FUTURE_PROMISE_TEST_PROD_DIV_H
int test_prod_div();
#endif //EXEMPLE_FUTURE_PROMISE_TEST_PROD_DIV_H
