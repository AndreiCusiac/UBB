//
// Created by Virginia Niculescu on 11/20/20.
//

#ifndef EXEMPLE_FUTURE_PROMISE_TEST_FUTURE_VECTOR_H
#define EXEMPLE_FUTURE_PROMISE_TEST_FUTURE_VECTOR_H
#include <future>
#include <iostream>
#include <vector>
int test_future_vector();
#endif //EXEMPLE_FUTURE_PROMISE_TEST_FUTURE_VECTOR_H
