package com.example.tinder.service.interfaces;

public interface AnimalService {

}
