package com.example.tinder.service.implementations;

import com.example.tinder.service.interfaces.AnimalService;
import org.springframework.stereotype.Service;

@Service
public class AnimalServiceImpl implements AnimalService {
}
