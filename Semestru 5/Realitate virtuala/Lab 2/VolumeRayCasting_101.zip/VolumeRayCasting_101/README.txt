Place RAW files in bin\x86\Debug(or Release)\Content\Models\
Do not add them to the project. The content pipeline
does not recognize raw files. An importer is out of the scope
for this project.

A Shader Model 3.0 graphics card is required to run this sample.
A Content processor that uses the most recent fx compiler is also included.
The default effect compiler is out of date for the options used in the RayCasting.fx file.