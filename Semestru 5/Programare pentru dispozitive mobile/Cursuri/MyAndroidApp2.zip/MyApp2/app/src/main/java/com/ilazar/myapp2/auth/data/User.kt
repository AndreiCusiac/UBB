package com.ilazar.myapp2.auth.data

data class User(
    val username: String,
    val password: String
)
