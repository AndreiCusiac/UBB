package com.ilazar.myapp2.auth.data

data class TokenHolder(
    val token: String
)
