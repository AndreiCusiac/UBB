package com.ilazar.myapp.auth.data.remote

data class User(
    val username: String,
    val password: String
)
