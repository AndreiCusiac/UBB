package com.ilazar.myapp.core.data

data class UserPreferences(val username: String = "", val token: String = "")
