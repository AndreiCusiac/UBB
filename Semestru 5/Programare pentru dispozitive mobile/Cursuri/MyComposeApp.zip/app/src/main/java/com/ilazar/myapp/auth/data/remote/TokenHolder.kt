package com.ilazar.myapp.auth.data.remote

data class TokenHolder(
    val token: String
)
