#include "QTHelloWorldWidgets.h"

QTHelloWorldWidgets::QTHelloWorldWidgets(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
