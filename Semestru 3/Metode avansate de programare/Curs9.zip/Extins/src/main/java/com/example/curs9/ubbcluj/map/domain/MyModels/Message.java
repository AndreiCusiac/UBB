package com.example.curs9.ubbcluj.map.domain.MyModels;

/**
 * reply e null daca mesajul nou creat nu est eun raspuns, iar daca nu e null reply <- mesajul la care este raspuns
 */
public class Message {
    String id_mesaj;
    String id_From;
    String id_To;
    String mesaj;
    String data;
    String reply;

    public String getData() {
        return data;
    }

    /**
     * Constructor
     * @param id_mesaj id-ul mesajului
     * @param id_From id-ul celui care a trimis mesajul
     * @param id_To lista id-urilor celor catre a fost trimis mesajul
     * @param mesaj String
     */
    public Message(String id_mesaj, String id_From, String id_To, String mesaj,String data,String id_reply) {
        this.id_mesaj = id_mesaj;
        this.id_From = id_From;
        this.id_To = id_To;
        this.mesaj = mesaj;
        this.data=data;
        this.reply=id_reply;
    }

    public String getId_mesaj() {
        return id_mesaj;
    }

    public String getId_From() {
        return id_From;
    }

    public String getId_To() {
        return id_To;
    }

    public String getMesaj() {
        return mesaj;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }
}
