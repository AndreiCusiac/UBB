package com.example.curs9;

import com.example.curs9.ubbcluj.map.domain.MyModels.Friendship;
import com.example.curs9.ubbcluj.map.domain.MyModels.Message;
import com.example.curs9.ubbcluj.map.domain.MyModels.User;
import com.example.curs9.ubbcluj.map.domain.MyUtils.MyObserver.Observer;
import com.example.curs9.ubbcluj.map.domain.MyValidators.FriendshipRepoValidator;
import com.example.curs9.ubbcluj.map.domain.MyValidators.MessageRepoValidator;
import com.example.curs9.ubbcluj.map.domain.MyValidators.UserRepoValidator;
import com.example.curs9.ubbcluj.map.service.NetworkService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MessageController implements Observer{
    NetworkService networkService;
    ObservableList<User> modelFriendsTable = FXCollections.observableArrayList();
    ObservableList<Message> chatMessages = FXCollections.observableArrayList();

    Stage currentStage;

    User currentUser;

    @FXML
    TableView<User> tableFriends;

    @FXML
    TableColumn<User, String> tableColumnNume;

    @FXML
    TableColumn<User, String> tableColumnPrenume;

    @FXML
    private ListView<Message> lvChatWindow;

    @FXML
    private TextField tfUser1;

    @FXML
    private TextField tfUser2;

    private void initNrMessages() throws MessageRepoValidator {
        networkService.setCurrentNrMessages();
    }

    public void setService(NetworkService networkService1, Stage currentStage1) throws UserRepoValidator, FriendshipRepoValidator, MessageRepoValidator {
        networkService = networkService1;
        //networkService.addObserver(this);
        currentUser = networkService.getCurrentUser();
        currentStage = currentStage1;
        initFriends();
        initNrMessages();
    }

    private void initMessages() throws MessageRepoValidator {
        chatMessages.setAll(getConversation(currentUser));
    }

    private void initFriends() throws UserRepoValidator, FriendshipRepoValidator {
        modelFriendsTable.setAll(getFriendsOfList(currentUser));
    }

    private List<User> getFriendsOfList(User currentUser1) throws UserRepoValidator, FriendshipRepoValidator {
        Iterable<User> users = networkService.getFriendsOf(currentUser1);
        List<User> usersList = StreamSupport.stream(users.spliterator(), false)
                .collect(Collectors.toList());
        return usersList;
    }

    private List<Message> getConversation(User currentUser) throws MessageRepoValidator {
        User selectedUser = tableFriends.getSelectionModel().getSelectedItem();
        Iterable<Message> messages=networkService.getConversation(currentUser.getId(),selectedUser.getId());
        List<Message> messageList = StreamSupport.stream(messages.spliterator(), false)
                .collect(Collectors.toList());
        return messageList;
    }

    @FXML
    public void handleShowConversation() {

        lvChatWindow.setItems(chatMessages);


    }

    @FXML
    public void initialize() {
        tableColumnNume.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));
        tableColumnPrenume.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));
        tableFriends.setItems(modelFriendsTable);

        tableFriends.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            try {
                initMessages();

                lvChatWindow.setItems(chatMessages);
                lvChatWindow.setCellFactory(param -> {
                    ListCell<Message> cell = new ListCell<Message>(){
                        Label lblUserLeft = new Label();
                        Label lblTextLeft = new Label();
                        HBox hBoxLeft = new HBox(lblUserLeft, lblTextLeft);

                        Label lblUserRight = new Label();
                        Label lblTextRight = new Label();
                        HBox hBoxRight = new HBox(lblTextRight, lblUserRight);

                        {
                            hBoxLeft.setAlignment(Pos.CENTER_LEFT);
                            hBoxLeft.setSpacing(5);
                            hBoxRight.setAlignment(Pos.CENTER_RIGHT);
                            hBoxRight.setSpacing(5);
                        }
                        @Override
                        protected void updateItem(Message item, boolean empty) {
                            super.updateItem(item, empty);

                            if(empty)
                            {
                                setText(null);
                                setGraphic(null);
                            }
                            else{
                                //System.out.println(item.getUser());
                                if(item.getId_To().equals(currentUser.getId()))
                                {
                                    lblUserLeft.setText("");
                                    lblTextLeft.setText(item.getMesaj());
                                    setGraphic(hBoxLeft);
                                }
                                else{
                                    lblUserRight.setText("");
                                    lblTextRight.setText(item.getMesaj());
                                    setGraphic(hBoxRight);
                                }
                            }
                        }

                    };

                    return cell;
                });


            } catch (MessageRepoValidator e) {
                e.printStackTrace();
            }
        });



    }

    @FXML
    private void handleUser1SubmitMessage(ActionEvent event) throws Exception {
        networkService.increaseNrMessages();
        User selectedUser = tableFriends.getSelectionModel().getSelectedItem();
        networkService.addNewMessage(String.valueOf(networkService.getNrMessages()),networkService.getCurrentUser().getId(),selectedUser.getId(),tfUser1.getText());
        tfUser1.setText("");
    }

    @FXML
    public void handleRefresh(ActionEvent actionEvent) throws UserRepoValidator, FriendshipRepoValidator, MessageRepoValidator {
        currentStage.getScene().setCursor(Cursor.WAIT);

        initMessages();

        currentStage.getScene().setCursor(Cursor.DEFAULT);
        //MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Refresh", "Tabele actualizate cu succes!");
    }

    @Override
    public void update() {
        try {
            initMessages();
        } catch (MessageRepoValidator e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void handleHome(ActionEvent actionEvent) throws UserRepoValidator, FriendshipRepoValidator {
        Stage stage = new Stage();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("home-view.fxml"));

        //FXMLLoader fxmlLoader = new FXMLLoader(StarterApplication.class.getResource("app-view.fxml"));
        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load(), 900, 600);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setTitle("Spicee");
        stage.setScene(scene);
        stage.show();

        currentStage.close();

        HomeController homeController = fxmlLoader.getController();
        homeController.setService(networkService, stage);
    }

    @FXML
    public void handleExit(ActionEvent actionEvent){
        currentStage.close();
    }
}
