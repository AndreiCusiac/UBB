package com.example.curs9.ubbcluj.map.domain.MyUtils.MyObserver;

public interface Observer {
    void update();
}