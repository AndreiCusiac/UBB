package com.example.filter_sem9;
public class Main {
    public static void main(String[] args) {
        TestSem9.main(args);
    }
}
