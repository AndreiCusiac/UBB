public class SimpleRoom implements Room {
      
      public String showRoom() {  
        return "Normal Room";  
      }  
      
    }  


