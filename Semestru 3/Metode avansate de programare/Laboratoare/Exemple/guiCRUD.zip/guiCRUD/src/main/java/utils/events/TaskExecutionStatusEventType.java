package utils.events;

public enum TaskExecutionStatusEventType {
    Running, Completed, Cancelled
}
