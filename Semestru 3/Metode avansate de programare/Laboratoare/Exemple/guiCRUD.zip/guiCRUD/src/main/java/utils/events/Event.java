package utils.events;

public interface Event {
}
