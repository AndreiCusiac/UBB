package ro.ubb.map.demogui.utils.events;

public enum TaskExecutionStatusEventType {
    Running, Completed, Cancelled
}
